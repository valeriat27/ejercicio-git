#3) Pide una temperatura en grados Celsius y conviértela a Fahrenheit. Muestra el resultado.

#solicitamos temperatura

tpt=input("Enter the temperature to convert--->")

#validamos que no sea alpha numerico

if tpt .isalpha():
    print("invalid")
else:
    #convertimos el string a decimal
    celsius=float(tpt)

    #ecuacion para la conversion de temperaturas

    f=(celsius*1.8)+32

    print("Temperature in fahrenheit--> "+f)

