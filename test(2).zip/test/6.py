# 6) Solicita un número y muestra si es positivo, negativo o igual a cero.

number=input(("Enter a Number---> "))

while number .isalpha():
    print("Invalid")
    number=input(("Enter a valid date---> "))

#convertimos el string recibido a numeros

numberCv=float(number) 

if numberCv < 0:
    print("the number is negative")

elif numberCv == 0:
    print("the number is 0")
else:
    print("the number is positive")