#1) Hola Mundo personalizado
#Pide al usuario su nombre y muestra un saludo personalizado en pantalla.

#primero pedimos al usuario su nombre

#almacenamos en la variable name el dato dado por el usuarios esperando un string 

name=input("¿What is your name?--->")


#luego validamos si singresaron un string y no otro tipo de dato ya que un nombre no puede ser un numero 
if name .isalpha():
  print("Hi "+name)
else:
 print("Invalid name, enter a string")

  