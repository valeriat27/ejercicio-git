#Solicita dos números y muestra cuál es el mayor. Si son iguales, indícalo.

numberOne=input("Enter number 1---> ")


#validamos que no ingresen letras

while numberOne .isalpha():
    print("Invalid Date")
    numberOne=input("Enter valid number 1---> ")


numberTwo=input("Enter number 2--> ")

while numberTwo .isalpha():
    print("Invalid Date")
    numberTwo=input("Enter valid number 2--> ")

#convertimos los datos ingresados a numeros

n1=float(numberOne)
n2=float(numberTwo)

if n1>n2:
  print('El primer número es mayor.')
elif n1<n2:
  print('El primer número es menor.')
else:
  print('Es el mismo número.')