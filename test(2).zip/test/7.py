
# 7) Pide un número entero al usuario y muestra si es par o impar.

number=input("Enter a number--> ")

#validamos si lo ingresado es un numero 

while number .isalpha():
    print("Invalid Date")
    number=input("Enter a valid date--> ")

#convertimos el string a numeros

numberCv=int(number)

#realizamos la validacion si es par o impar

if numberCv %2==0:
    print("is par")

else:
    print("is impar")


