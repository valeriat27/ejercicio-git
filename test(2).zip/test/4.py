#4) Pide al usuario la base y la altura de un rectángulo y calcula su área.

#solicitamos la base del rectangulo

base=input(("Enter base --> "))

#validamos que la base sea un numero y no una letra
while base .isalpha():
    print("invalid date")
    base=input(("Enter base valida --> "))
    
  
#solicitamos la altura del rectangulo

height=input(("Enter height-->"))

#validamos que la altura sea un numero y no una letra
if base .isalpha():
    print("invalid date")

#convertimos los datos recibidos como string a float

numberBase=float(base)
numberHeight=float(height)

#formula
area=numberBase*numberHeight

print(area)
