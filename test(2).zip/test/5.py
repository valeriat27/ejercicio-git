#5) Pide al usuario su edad y muestra cuántos años tendrá dentro de 5 años.


age=input(("¿How  old are you?--> "))

while age .isalpha():
    print("Invalid Age")
    age=input(("Enter a valid age--> "))

#convertimos la edad recibida en entero

ageFuture=int(age)

#prediccion

future=ageFuture+5

print(future)


