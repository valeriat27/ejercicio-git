#2) Solicita dos números al usuario, realiza la suma y muestra el resultado.

#primero creo dos variables y les asigno la entrad de datos del usuario esperando numeros de tipo float
numberOne=(input("Enter number---> "))
numberTwo=(input("Enter number---->" ))

#validamos que no ingresen letras para sumar

if numberOne .isalpha():
    print("invalid")
elif numberTwo .isalpha():
    print("invalid")
else:   
    #las variables numberOne y numberTwo estan recibiendo un string asi que debemos convertir
    #esas variables a tipo decimal para sumarse 

    #convercion
    n1=float(numberOne)
    n2=float(numberTwo)

    #operacion
    suma=n1+n2
    print(suma)
 