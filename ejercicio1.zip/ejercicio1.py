while True:

    nombre = str(input("nombre del producto: "))
    while True:
        precio = float(input("precio unitario: "))
        if precio > 0:
            break
        print("te equivocaste")
        print("volver a intentarlo")
    cantidad = int(input("cantidad de productos adquiridos: "))
    porcentaje = float(input("porcentaje del descuento: "))

    total = precio * cantidad
    descuento = total * (porcentaje / 100)
    total_descuento = total-descuento
    print(total_descuento)

    while 0 >= descuento >= 100:
        print("te equivocaste") 
        break  

    while cantidad <= 0:
        print ("te equivocaste")
        break

    print(f"{nombre},{precio},{total},{total_descuento}")

    respuesta = input("¿deseas repetir el proceso? (s/n): ")
    if respuesta.lower() != 's':
        break
